from view.screens.default_screen import DefaultScreen

class ScreenManager:
    def __init__(self, root, app_logic):
        self.root = root
        self.app_logic = app_logic
        self.current_screen = None
        self.screen_stack = []

    def load_screen(self, screen_name="default", remember=True):
        # Store previous screen if needed
        if self.current_screen and remember:
            self.screen_stack.append(self.current_screen)

        # Remove old screen
        if self.current_screen:
            self.current_screen.unmount()

        # Load new screen
        if screen_name == "default":
            from view.screens.default_screen import DefaultScreen
            self.current_screen = DefaultScreen(self.root, self.app_logic)

        self.current_screen.render()

    def go_back(self):
        if self.screen_stack:
            # Destroy current before popping back
            if self.current_screen:
                self.current_screen.destroy()
            self.current_screen = self.screen_stack.pop()
            self.current_screen.show()
        else:
            print("[ScreenManager] No previous screen in breadcrumb stack.")

    def destroy_current_screen(self):
        if self.current_screen:
            self.current_screen.destroy()
            self.current_screen = None

    def clear_history(self):
        self.screen_stack.clear()
