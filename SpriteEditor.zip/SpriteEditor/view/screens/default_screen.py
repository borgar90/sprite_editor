# view/screens/default_screen.py
from view.screens.screen import Screen
from view.layouts.default_layout import DefaultLayout


class DefaultScreen(Screen):
    def build_layout(self):
        self.layout = DefaultLayout(self.parent, self.app_logic)
