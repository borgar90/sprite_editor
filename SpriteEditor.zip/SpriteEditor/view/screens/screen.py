# view/screens/screen.py
from abc import ABC, abstractmethod
from view.layouts.layout import Layout


class Screen(ABC):
    def __init__(self, parent, app_logic):
        self.parent = parent
        self.app_logic = app_logic
        self.layout = None

    @abstractmethod
    def build_layout(self):
        """This should initialize and assign self.layout"""
        pass

    def render(self):
        if not self.layout:
            self.build_layout()
        self.layout.render()
