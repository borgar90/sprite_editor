# view/view.py
class View:
    def __init__(self, root):
        self.root = root

    def render(self):
        raise NotImplementedError("render() must be implemented by subclass")
