# view/sections/left_panel_section.py
from tkinter import ttk
from .base_section import Section

class LeftPanelSection(Section):
    def __init__(self, parent, app_logic, on_switch_mode, on_open_palette):
        super().__init__(parent, app_logic)

        self.label = ttk.Label(self.frame, text="🛠️ Painter Mode", font=("Arial", 12, "bold"))
        self.label.pack(anchor="w", pady=(0, 10))

        # Insert tool buttons or dynamic elements here (future widgets/elements)
        # self.button = ttk.Button(self.frame, text="Tool", command=...)
