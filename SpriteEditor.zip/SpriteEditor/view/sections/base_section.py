# view/sections/base_section.py
import tkinter as tk


class Section:
    def __init__(self, parent, app_logic):
        self.parent = parent
        self.app_logic = app_logic
        self.frame = tk.Frame(parent)

    def render(self, **pack_opts):
        """Pack this section's frame into its parent with given options"""
        self.frame.pack(**pack_opts)

    def get_frame(self):
        return self.frame
