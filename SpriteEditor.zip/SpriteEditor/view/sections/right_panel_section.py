# view/sections/right_panel_section.py
from base_section import Section
from app.right_panel import RightPanel

class RightPanelSection(Section):
    def __init__(self, parent, app_logic, on_grid_updated):
        super().__init__(parent, app_logic)
        self.panel = RightPanel(self.frame, app_logic, on_grid_updated)
