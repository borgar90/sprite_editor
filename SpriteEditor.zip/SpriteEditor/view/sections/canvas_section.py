# view/sections/canvas_section.py
from base_section import Section
from app.painter_canvas import PainterCanvas

class CanvasSection(Section):
    def __init__(self, parent, app_logic):
        super().__init__(parent, app_logic)
        self.canvas = PainterCanvas(self.frame, app_logic)

    def get_canvas(self):
        return self.canvas
