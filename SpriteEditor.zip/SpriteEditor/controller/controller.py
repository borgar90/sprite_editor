# controller/controller.py
class Controller:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def bind_events(self):
        raise NotImplementedError("bind_events() must be implemented by subclass")
