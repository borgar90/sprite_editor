# model/model.py
class Model:
    def __init__(self):
        self._observers = []

    def add_observer(self, callback):
        self._observers.append(callback)

    def notify_observers(self):
        for callback in self._observers:
            callback()
